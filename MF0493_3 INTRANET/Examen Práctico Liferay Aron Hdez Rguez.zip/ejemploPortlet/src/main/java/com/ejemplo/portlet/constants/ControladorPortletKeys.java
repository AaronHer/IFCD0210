package com.ejemplo.portlet.constants;

/**
 * @author aula1
 */
public class ControladorPortletKeys {

	public static final String Controlador = "controlador";

}